"""
the weibo robot can send weibo automatically,without getting url by the url in the browser mannually.

when you set up your app in weibo develop platform,you can get app_key ,app_secret,callback_url.

meanwhile,you should have weibo account.username and password is necessary.

"""
from  weiborobot import WeiboRobot
from auth import WeiboAuth


